//
//  ViewController.swift
//  smile
//
//  Created by Nabeel Ahmad Khan on 24/10/17.
//  Copyright © 2017 Defcon. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase


//UITextField : override textRect, editingRect, This class is defined to give left padding in the TextField.
//Select LeftPaddedTextField as the class for the TextField from the Storyboard.
class LeftPaddedTextField: UITextField {
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        return CGRect(x: bounds.origin.x + 50, y: bounds.origin.y, width: bounds.width - 70, height: bounds.height)
    }
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        return CGRect(x: bounds.origin.x + 50, y: bounds.origin.y, width: bounds.width - 70 , height: bounds.height)
    }
}

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userName: LeftPaddedTextField!
    @IBOutlet weak var password: LeftPaddedTextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var forgetPasswordButton: UIButton!
    @IBOutlet weak var createAccountButton: UIButton!
    @IBOutlet weak var loginLabel: UILabel!
    
    // Function defined to navigate the TextField to new TextField on pressing Next on the keyboard.
    // Tor run this function "tags" should be set for the individual TextField in incremental Order.
    // & the delegate for the TextField should be the ViewController.
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        let tag = textField.tag + 1 as Int
        let nextField: UIResponder? = textField.superview?.viewWithTag(tag)
        
        if let field: UIResponder = nextField{
            field.becomeFirstResponder()
        }
        else{
            textField.resignFirstResponder()
        }
        return false
    }
    
    @IBAction func loginAction(_ sender: Any) {
        let loginID = userName.text
        let userPass = password.text
        
        
        Auth.auth().signIn(withEmail: loginID!, password: userPass!) { (user, error) in
            // ...
            if error == nil {
                self.loginLabel.text = "You are successfully Logged In"
                //self.performSegue(withIdentifier: "loginSegue", sender: nil)
                self.performSeguetoUserProfile()
            }else{
                self.loginLabel.text = "Log-In Failed.. Please Try Again"
            }
        }
    }
    
    // Performing Segue to UserProfile Page
    func performSeguetoUserProfile() {
        print("Perform segue called")
        DispatchQueue.main.async(){
            self.performSegue(withIdentifier: "loginSegue", sender: self)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (Auth.auth().currentUser?.uid) != nil{
            let email = Auth.auth().currentUser?.email
            print("The user is already signed in. as \(email)")
            performSeguetoUserProfile() // Performing seque to UserProfile page of the user is already signed in.
        }
        else{
            print("tHE USER IS NOR SIGNED IN ")
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

