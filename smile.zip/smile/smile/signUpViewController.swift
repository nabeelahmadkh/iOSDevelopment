//
//  signUpViewController.swift
//  smile
//
//  Created by Nabeel Ahmad Khan on 25/10/17.
//  Copyright © 2017 Defcon. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseDatabase


//UITextField : override textRect, editingRect, This class is defined to give left padding in the TextField.
//Select LeftPaddedTextField as the class for the TextField from the Storyboard.
//This class is different from the class declared in ViewController.swift file
class LeftPaddedTextField2: UITextField {
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        return CGRect(x: bounds.origin.x + 20, y: bounds.origin.y, width: bounds.width - 30, height: bounds.height)
    }
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        return CGRect(x: bounds.origin.x + 20, y: bounds.origin.y, width: bounds.width - 30 , height: bounds.height)
    }
}


class signUpViewController:UIViewController{

    // Declaring variables for the SignUp View Controller
    @IBOutlet weak var signUpTextLabel: UILabel!
    @IBOutlet weak var usernameTextField: LeftPaddedTextField2!
    @IBOutlet weak var passwordTextField: LeftPaddedTextField2!
    @IBOutlet weak var confirmPasswordTextField: LeftPaddedTextField2!
    var sexButton:String? = nil
    @IBOutlet weak var sexLabel: UILabel!
    @IBOutlet weak var hobbiesTextField: LeftPaddedTextField2!
    @IBOutlet weak var dateOfBirthTextField: LeftPaddedTextField2!
    @IBOutlet weak var signUpConfirmationLabel: UILabel!
    @IBOutlet weak var passwordNoMatch: UILabel!
    var noErrorFlag = 0x01
    
    //Radio Button Selected
    @IBAction func femaleRadioButtonPressed(_ sender: Any) {
        print("Female Radio Button Selected")
        sexButton = "Female"
    }
    @IBAction func maleRadioButtonPressed(_ sender: Any) {
        print("Male Radio Button Selected")
        sexButton = "Male"
    }
    
    // Password Length and Matching Check
    @IBAction func confirmPassword(_ sender: Any) {
        let lengthOfPassword:Int = (confirmPasswordTextField.text?.count)!
        if (lengthOfPassword >= 6){
            if passwordTextField.text == confirmPasswordTextField.text{
                print("Length of Password is greator than or equal to 6")
                noErrorFlag = 0x02
                passwordNoMatch.text = ""
            }
            else{
                passwordNoMatch.text = "NO MATCH!!!"
                noErrorFlag = 0x01
            }
        }
        else{
            passwordNoMatch.text = "LENGTH<6!!!"
            noErrorFlag = 0x01
        }
    }
    
    @IBAction func signUpButton(_ sender: UIButton) {
        if noErrorFlag == 0x02{
            let email = usernameTextField.text
            let password = passwordTextField.text
            let sexLabel = sexButton
            let dateOfBirth = dateOfBirthTextField.text
            let ref = Database.database().reference().root
            
            
            Auth.auth().createUser(withEmail: email!, password: password!, completion: { (user: User?, error) in
                if error == nil {
                    // Adding additional information of the user to the database
                    ref.child("users").child((user?.uid)!).child("email").setValue(email)
                    ref.child("users").child((user?.uid)!).child("dob").setValue(dateOfBirth)
                    ref.child("users").child((user?.uid)!).child("sex").setValue(sexLabel)
                    
                        print("The information has been successfully added")
                        self.signUpConfirmationLabel.text = "Your Information has been succesfully added"
                    
                        // Logging Out because the user was automatically signing in after registration.
                        let firebaseAuth = Auth.auth()
                        do {
                            try firebaseAuth.signOut()
                            print("The user successfully signed out of the app")
                        } catch let signOutError as NSError {
                            print ("Error signing out: %@", signOutError)
                        }
                    
                        DispatchQueue.main.async(){
                        self.performSegue(withIdentifier: "signupToLogin", sender: self)
                        }
                    
                }else{
                    self.signUpConfirmationLabel.text = "Registration Failed.. Please Try Again"
                }
            })
        }
        else{
            print("Condition not matching")
            signUpConfirmationLabel.text = "One or More Mandatory things missing."
        }
    }
    
    
    override func viewDidLoad() {
        // Assinging Font, Size & Color to the TextFields
        usernameTextField.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        usernameTextField.textColor = UIColor.white
        
        signUpTextLabel.font = UIFont(name: "ChalkboardSE-Bold", size: 24.0)
        signUpTextLabel.textColor = UIColor.white
        
        passwordTextField.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        passwordTextField.textColor = UIColor.white
        
        confirmPasswordTextField.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        confirmPasswordTextField.textColor = UIColor.white
        
        sexLabel.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        sexLabel.textColor = UIColor.white
        
        hobbiesTextField.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        hobbiesTextField.textColor = UIColor.white
        
        dateOfBirthTextField.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        dateOfBirthTextField.textColor = UIColor.white
        
        signUpConfirmationLabel.font = UIFont(name: "ChalkboardSE-Bold", size: 18.0)
        signUpConfirmationLabel.textColor = UIColor.red
        
        passwordNoMatch.font = UIFont(name: "ChalkboardSE-Bold", size: 16.0)
        passwordNoMatch.textColor = UIColor.red
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
