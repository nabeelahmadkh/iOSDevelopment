//
//  tempViewController.swift
//  smile
//
//  Created by Nabeel Ahmad Khan on 02/11/17.
//  Copyright © 2017 Defcon. All rights reserved.
//

import Foundation
import UIKit

class tempViewController: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
